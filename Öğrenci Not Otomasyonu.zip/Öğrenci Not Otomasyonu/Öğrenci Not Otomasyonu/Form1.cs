﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Öğrenci_Not_Otomasyonu
{
    public partial class Form1 : Form
    {
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\veritabani.accdb");

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        public static string ogrNo = "";
        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            if (txtKullaniciAdi.Text == "0")
            {
                OgretmenBilgileriFormu ogr = new OgretmenBilgileriFormu();
                this.Hide();
                ogr.Show();
            }
            else
            {
                OleDbCommand cmd = new OleDbCommand();
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandText = "SELECT * FROM ogrenciler where numara=@p1";
                cmd.Parameters.AddWithValue("@p1", txtKullaniciAdi.Text);
                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    ogrNo = dr["numara"].ToString();
                    OgrenciBilgileriFormu ogrBilgiForm = new OgrenciBilgileriFormu();
                    this.Hide();
                    ogrBilgiForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Numara yalnış", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                conn.Close();
            }

            


           
          
        }
    }
}
