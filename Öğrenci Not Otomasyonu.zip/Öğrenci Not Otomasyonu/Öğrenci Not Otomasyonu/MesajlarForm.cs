﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Öğrenci_Not_Otomasyonu
{
    public partial class MesajlarForm : Form
    {
        public MesajlarForm()
        {
            InitializeComponent();
        }
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\veritabani.accdb");
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OgretmenBilgileriFormu ogr = new OgretmenBilgileriFormu();
            this.Hide();
            ogr.ShowDialog();
        }

        private void MesajlarForm_Load(object sender, EventArgs e)
        {
         
            OleDbDataAdapter da = new OleDbDataAdapter("SElect *from mesajlar", conn);
            DataSet ds = new DataSet();
            conn.Open();
            da.Fill(ds, "mesaj_konu");
            dataGridView1.DataSource = ds.Tables["mesaj_konu"];
            conn.Close();
        }
    }
}
