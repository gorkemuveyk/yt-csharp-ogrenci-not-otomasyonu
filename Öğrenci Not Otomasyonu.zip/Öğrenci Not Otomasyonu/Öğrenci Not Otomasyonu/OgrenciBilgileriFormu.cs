﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Öğrenci_Not_Otomasyonu
{
    public partial class OgrenciBilgileriFormu : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\veritabani.accdb");
        public OgrenciBilgileriFormu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void OgrenciBilgileriFormu_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void btnOgretmeneMesajGonder_Click(object sender, EventArgs e)
        {
            MesajGonderForm mj = new MesajGonderForm();
            this.Hide();
            mj.ShowDialog();
        }

        private void OgrenciBilgileriFormu_Load(object sender, EventArgs e)
        {
            conn.Open();
            OleDbCommand verioku = new OleDbCommand("select * from notlar where ogrenci_numara=@p1", conn);
            verioku.Parameters.AddWithValue("@p1", Form1.ogrNo);
            verioku.ExecuteNonQuery();
            OleDbDataReader oku;
            oku = verioku.ExecuteReader();

            while (oku.Read())
            {
                dersBirNot.Text = oku["FizikVize"] + " - " + oku["FizikFinal"] + " - " + oku["FizikOrt"];
                dersIkiNot.Text = oku["MatVize"] + " - " + oku["MatFinal"] + " - " + oku["MatOrt"];
                dersUcNot.Text = oku["SemantikWebVize"] + " - " + oku["SemantikWebFinal"] + " - " + oku["SemantikWebOrt"];
                dersDortNot.Text = oku["MobilProgVize"] + " - " + oku["MobilProgFinal"] + " - " + oku["MobilProgOrt"];
                dersBesNot.Text = oku["YazılımMimariVize"] + " - " + oku["YazılımMimariFinal"] + " - " + oku["YazılımMimariOrt"];
            }
        
            conn.Close();




            conn.Open();
            OleDbCommand verioku2 = new OleDbCommand("select * from ogrenciler where numara=@p1", conn);
            verioku2.Parameters.AddWithValue("@p1", Form1.ogrNo);
            verioku2.ExecuteNonQuery();
            OleDbDataReader oku2;
            oku2 = verioku2.ExecuteReader();

            while (oku2.Read())
            {
                lblOgrenciAdi.Text = oku2["Ad"] + " " + oku2["Soyad"];
                pictureBox2.ImageLocation = oku2["foto_yol"].ToString();

            }
            oku2.Close();
            conn.Close();
        }
    }
}
