﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Öğrenci_Not_Otomasyonu
{
    public partial class OgretmenBilgileriFormu : Form
    {

        private FilterInfoCollection webcam;//webcam isminde tanımladığımız değişken bilgisayara kaç kamera bağlıysa onları tutan bir dizi. 
        private VideoCaptureDevice cam;//cam ise bizim kullanacağımız aygıt.

        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\veritabani.accdb");
        OleDbCommand cmd;
        OleDbDataAdapter da;
        DataSet ds;


        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public OgretmenBilgileriFormu()
        {
            InitializeComponent();
        }

        private void OgretmenBilgileriFormu_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txtMatematikVize.Text.Length > 0)
            {
                if (int.Parse(txtMatematikVize.Text) > 100)
                {
                    txtMatematikVize.Text = "100";
                }
                if (int.Parse(txtMatematikVize.Text) < 0)
                {
                    txtMatematikVize.Text = "0";
                }
            }


            if (txtMatematikFinal.Text.Length > 0)
            {
                lblMatematikOrt.Text = (int.Parse(txtMatematikVize.Text) * 0.4 + int.Parse(txtMatematikFinal.Text) * 0.6).ToString("0.00");


                if (double.Parse(lblMatematikOrt.Text) >= 60)
                {
                    lblMatematikOrt.BackColor = Color.Green;
                }
                else
                {
                    lblMatematikOrt.BackColor = Color.Red;
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (txtMatematikFinal.Text.Length > 0)
            {
                if (double.Parse(txtMatematikFinal.Text) > 100)
                {
                    txtMatematikFinal.Text = "100";
                }
                if (double.Parse(txtMatematikFinal.Text) < 0)
                {
                    txtMatematikFinal.Text = "0";
                }
            }




            if (txtMatematikVize.Text.Length > 0)
            {
                lblMatematikOrt.Text = (int.Parse(txtMatematikVize.Text) * 0.4 + int.Parse(txtMatematikFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblMatematikOrt.Text) >= 60)
                {
                    lblMatematikOrt.BackColor = Color.Green;
                }
                else
                {
                    lblMatematikOrt.BackColor = Color.Red;
                }

            }



        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtFizikVize_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtFizikVize_TextChanged(object sender, EventArgs e)
        {
            if (txtFizikVize.Text.Length > 0)
            {
                if (int.Parse(txtFizikVize.Text) > 100)
                {
                    txtFizikVize.Text = "100";
                }
                if (int.Parse(txtFizikVize.Text) < 0)
                {
                    txtFizikVize.Text = "0";
                }
            }



            if (txtFizikFinal.Text.Length > 0)
            {
                lblFizikOrt.Text = (int.Parse(txtFizikVize.Text) * 0.4 + int.Parse(txtFizikFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblFizikOrt.Text) >= 60)
                {
                    lblFizikOrt.BackColor = Color.Green;
                }
                else
                {
                    lblFizikOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtFizikFinal_TextChanged(object sender, EventArgs e)
        {
            if (txtFizikFinal.Text.Length > 0)
            {
                if (int.Parse(txtFizikFinal.Text) > 100)
                {
                    txtFizikFinal.Text = "100";
                }
                if (int.Parse(txtFizikFinal.Text) < 0)
                {
                    txtFizikFinal.Text = "0";
                }
            }

            if (txtFizikVize.Text.Length > 0)
            {
                lblFizikOrt.Text = (int.Parse(txtFizikVize.Text) * 0.4 + int.Parse(txtFizikFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblFizikOrt.Text) >= 60)
                {
                    lblFizikOrt.BackColor = Color.Green;
                }
                else
                {
                    lblFizikOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtMobilProgVize_TextChanged(object sender, EventArgs e)
        {
            if (txtMobilProgVize.Text.Length > 0)
            {
                if (int.Parse(txtMobilProgVize.Text) > 100)
                {
                    txtMobilProgVize.Text = "100";
                }
                if (int.Parse(txtMobilProgVize.Text) < 0)
                {
                    txtMobilProgVize.Text = "0";
                }
            }


            if (txtMobilProgFinal.Text.Length > 0)
            {
                lblMobilProgOrt.Text = (int.Parse(txtMobilProgVize.Text) * 0.4 + int.Parse(txtMobilProgFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblMobilProgOrt.Text) >= 60)
                {
                    lblMobilProgOrt.BackColor = Color.Green;
                }
                else
                {
                    lblMobilProgOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtMobilProgFinal_TextChanged(object sender, EventArgs e)
        {
            if (txtMobilProgFinal.Text.Length > 0)
            {
                if (int.Parse(txtMobilProgFinal.Text) > 100)
                {
                    txtMobilProgFinal.Text = "100";
                }
                if (int.Parse(txtMobilProgFinal.Text) < 0)
                {
                    txtMobilProgFinal.Text = "0";
                }
            }


            if (txtMobilProgVize.Text.Length > 0)
            {
                lblMobilProgOrt.Text = (int.Parse(txtMobilProgVize.Text) * 0.4 + int.Parse(txtMobilProgFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblMobilProgOrt.Text) >= 60)
                {
                    lblMobilProgOrt.BackColor = Color.Green;
                }
                else
                {
                    lblMobilProgOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtYazilimMimarileriVize_TextChanged(object sender, EventArgs e)
        {
            if (txtYazilimMimarileriVize.Text.Length > 0)
            {
                if (int.Parse(txtYazilimMimarileriVize.Text) > 100)
                {
                    txtYazilimMimarileriVize.Text = "100";
                }
                if (int.Parse(txtYazilimMimarileriVize.Text) < 0)
                {
                    txtYazilimMimarileriVize.Text = "0";
                }
            }


            if (txtYazılımMimarileriFinal.Text.Length > 0)
            {
                lblYazılımMimarileriOrt.Text = (int.Parse(txtYazilimMimarileriVize.Text) * 0.4 + int.Parse(txtYazılımMimarileriFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblYazılımMimarileriOrt.Text) >= 60)
                {
                    lblYazılımMimarileriOrt.BackColor = Color.Green;
                }
                else
                {
                    lblYazılımMimarileriOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtYazılımMimarileriFinal_TextChanged(object sender, EventArgs e)
        {
            if (txtYazılımMimarileriFinal.Text.Length > 0)
            {
                if (int.Parse(txtYazılımMimarileriFinal.Text) > 100)
                {
                    txtYazılımMimarileriFinal.Text = "100";
                }
                if (int.Parse(txtYazılımMimarileriFinal.Text) < 0)
                {
                    txtYazılımMimarileriFinal.Text = "0";
                }
            }

            if (txtYazilimMimarileriVize.Text.Length > 0)
            {
                lblYazılımMimarileriOrt.Text = (int.Parse(txtYazilimMimarileriVize.Text) * 0.4 + int.Parse(txtYazılımMimarileriFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblYazılımMimarileriOrt.Text) >= 60)
                {
                    lblYazılımMimarileriOrt.BackColor = Color.Green;
                }
                else
                {
                    lblYazılımMimarileriOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtSemantikWebVize_TextChanged(object sender, EventArgs e)
        {
            if (txtSemantikWebVize.Text.Length > 0)
            {
                if (int.Parse(txtSemantikWebVize.Text) > 100)
                {
                    txtSemantikWebVize.Text = "100";
                }
                if (int.Parse(txtSemantikWebVize.Text) < 0)
                {
                    txtSemantikWebVize.Text = "0";
                }
            }


            if (txtSemantikWebFinal.Text.Length > 0)
            {
                lblSemantikWebOrt.Text = (int.Parse(txtSemantikWebVize.Text) * 0.4 + int.Parse(txtSemantikWebFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblSemantikWebOrt.Text) >= 60)
                {
                    lblSemantikWebOrt.BackColor = Color.Green;
                }
                else
                {
                    lblSemantikWebOrt.BackColor = Color.Red;
                }
            }
        }

        private void txtSemantikWebFinal_TextChanged(object sender, EventArgs e)
        {
            if (txtSemantikWebFinal.Text.Length > 0)
            {
                if (int.Parse(txtSemantikWebFinal.Text) > 100)
                {
                    txtSemantikWebFinal.Text = "100";
                }
                if (int.Parse(txtSemantikWebFinal.Text) < 0)
                {
                    txtSemantikWebFinal.Text = "0";
                }
            }


            if (txtSemantikWebVize.Text.Length > 0)
            {
                lblSemantikWebOrt.Text = (int.Parse(txtSemantikWebVize.Text) * 0.4 + int.Parse(txtSemantikWebFinal.Text) * 0.6).ToString("0.00");

                if (double.Parse(lblSemantikWebOrt.Text) >= 60)
                {
                    lblSemantikWebOrt.BackColor = Color.Green;
                }
                else
                {
                    lblSemantikWebOrt.BackColor = Color.Red;
                }
            }
        }

        public int VarMi(string aranan)
        {
            int sonuc;

            cmd = new OleDbCommand("Select COUNT(numara) from Ogrenciler WHERE numara=@p1", conn);
            cmd.Parameters.AddWithValue("@p1", txtOgrNumara.Text);
            conn.Open();

            sonuc = Convert.ToInt32(cmd.ExecuteScalar());

            conn.Close();
            return sonuc;

        }

        void Temizle()
        {
            txtOgrAd.Text = "";
            txtOgrSoyad.Text = "";
            txtOgrNumara.Text = "";
            txtTelefon.Text = "";
            txtErkek.Checked = false;
            txtKadin.Checked = false;
        }
        private void btnKaydet_Click(object sender, EventArgs e)
        {
            string cinsiyet = "";
            if (txtErkek.Checked)
            {
                cinsiyet = "Erkek";
            }
            if (txtKadin.Checked)
            {
                cinsiyet = "Kadın";
            }

            if (txtOgrAd.Text != "" && txtOgrSoyad.Text != "" && txtTelefon.Text != "" && cinsiyet != "" && txtOgrNumara.Text != "")
            {
                if (VarMi(txtOgrNumara.Text) != 0)
                {
                    MessageBox.Show("Bu numarada öğrenci zaten kayıtlı!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {

                    conn.Open();
                    cmd = new OleDbCommand("insert into ogrenciler (ad, soyad, cinsiyet, telefon, kayit_tarihi, numara, foto_yol) values (@p1, @p2, @p3,  @p4, @p5, @p6, @p7)", conn);
                    cmd.Parameters.AddWithValue("@p1", txtOgrAd.Text);
                    cmd.Parameters.AddWithValue("@p2", txtOgrSoyad.Text);
                    cmd.Parameters.AddWithValue("@p3", cinsiyet);
                    cmd.Parameters.AddWithValue("@p4", txtTelefon.Text);
                    cmd.Parameters.AddWithValue("@p5", DateTime.Now.ToShortDateString());
                    cmd.Parameters.AddWithValue("@p6", txtOgrNumara.Text);
                    cmd.Parameters.AddWithValue("@p7", Application.StartupPath + "\\" + txtOgrAd.Text + "." + txtOgrSoyad.Text + "." + txtOgrNumara.Text + ".png");
                   
                    cmd.ExecuteNonQuery();
                    pictureBox4.Image.Save(txtOgrAd.Text + "." + txtOgrSoyad.Text + "." + txtOgrNumara.Text + ".png");
                    MessageBox.Show("Öğrenci Başarıyla Eklendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conn.Close();
                   


                    conn.Open();
                    cmd = new OleDbCommand("insert into notlar (ogrenci_numara, MatVize, MatFinal, MatOrt, FizikVize, FizikFinal, FizikOrt, SemantikWebVize, SemantikWebFinal, SemantikWebOrt, YazılımMimariVize, YazılımMimariFinal, YazılımMimariOrt, MobilProgVize, MobilProgFinal, MobilProgOrt) values (@p7, @p8 ,@p9 ,@p10, @p11, @p12, @p13, @p14, @p15, @p16, @p17, @p18, @p19, @p20, @p21, @p22)", conn);
                    cmd.Parameters.AddWithValue("@p7", txtOgrNumara.Text);
                    cmd.Parameters.AddWithValue("@p8", "0");
                    cmd.Parameters.AddWithValue("@p9", "0");
                    cmd.Parameters.AddWithValue("@p10", "0");
                    cmd.Parameters.AddWithValue("@p11", "0");
                    cmd.Parameters.AddWithValue("@p12", "0");
                    cmd.Parameters.AddWithValue("@p13", "0");
                    cmd.Parameters.AddWithValue("@p14", "0");
                    cmd.Parameters.AddWithValue("@p15", "0");
                    cmd.Parameters.AddWithValue("@p16", "0");
                    cmd.Parameters.AddWithValue("@p17", "0");
                    cmd.Parameters.AddWithValue("@p18", "0");
                    cmd.Parameters.AddWithValue("@p19", "0");
                    cmd.Parameters.AddWithValue("@p20", "0");
                    cmd.Parameters.AddWithValue("@p21", "0");
                    cmd.Parameters.AddWithValue("@p22", "0");
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    Temizle();
                    Listele();

                }
            }
            else
            {
                MessageBox.Show("Boş alan bırakmayın!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }






        }
        public void Listele()
        {
            cmbOgrenciSec.Items.Clear();
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM ogrenciler ORDER BY numara ASC", conn);
            OleDbDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cmbOgrenciSec.Items.Add(dr["numara"] + " - " + dr["ad"] + " " + dr["soyad"]);

            }
            conn.Close();
        }

        private void OgretmenBilgileriFormu_Load(object sender, EventArgs e)
        {
            webcam = new FilterInfoCollection(FilterCategory.VideoInputDevice);//webcam dizisine mevcut kameraları dolduruyoruz.
            foreach (FilterInfo videocapturedevice in webcam)
            {
                comboBox1.Items.Add(videocapturedevice.Name);//kameraları combobox a dolduruyoruz.
            }
            comboBox1.SelectedIndex = 0;


            Listele();

        }

        private void btnKamera_Click(object sender, EventArgs e)
        {
            if (btnKamera.Text == "Kamera Aç")
            {
                cam = new VideoCaptureDevice(webcam[comboBox1.SelectedIndex].MonikerString);
                cam.NewFrame += new NewFrameEventHandler(cam_NewFrame);
                cam.Start();

                btnKamera.Text = "Kamera Kapat";
            }


            else if (btnKamera.Text == "Kamera Kapat")
            {
                if (cam.IsRunning) //kamera açıksa kapatıyoruz.
                {
                    cam.Stop();
                    pictureBox3.Image = Image.FromFile(Application.StartupPath + "\\student.png");
                    btnKamera.Text = "Kamera Aç";
                }

            }
        }

        private void cam_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bit = (Bitmap)eventArgs.Frame.Clone();
            pictureBox3.Image = bit;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void OgretmenBilgileriFormu_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = pictureBox3.Image;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnGozat_Click(object sender, EventArgs e)
        {
            OpenFileDialog dosya = new OpenFileDialog();
            dosya.Filter = "Resim Dosyası |*.jpg;*.nef;*.png| Video|*.avi| Tüm Dosyalar |*.*";
            dosya.Title = "Öğrenci Resmi Seç";
            dosya.ShowDialog();
            string DosyaYolu = dosya.FileName;
            pictureBox4.ImageLocation = DosyaYolu;
        }



        private void btnNotVer_Click(object sender, EventArgs e)
        {
            if (cmbOgrenciSec.Text != "")
            {
                string[] ogrNo = cmbOgrenciSec.Text.Split('-');


                conn.Open();
                cmd = new OleDbCommand("UPDATE notlar SET MatVize=@p1, MatFinal=@p2, MatOrt=@p3, FizikVize=@p4, FizikFinal=@p5, FizikOrt=@p6, MobilProgVize=@p7, MobilProgFinal=@p8, MobilProgOrt=@p9, YazılımMimariVize=@p10, YazılımMimariFinal=@p11, YazılımMimariOrt=@p12, SemantikWebVize=@p13, SemantikWebFinal=@p14, SemantikWebOrt=@p15 WHERE ogrenci_numara=@p16", conn);

                cmd.Parameters.AddWithValue("@p1", txtMatematikVize.Text);
                cmd.Parameters.AddWithValue("@p2", txtMatematikFinal.Text);
                cmd.Parameters.AddWithValue("@p3", lblMatematikOrt.Text);
                cmd.Parameters.AddWithValue("@p4", txtFizikVize.Text);
                cmd.Parameters.AddWithValue("@p5", txtFizikFinal.Text);
                cmd.Parameters.AddWithValue("@p6", lblFizikOrt.Text);
                cmd.Parameters.AddWithValue("@p7", txtMobilProgVize.Text);
                cmd.Parameters.AddWithValue("@p8", txtMobilProgFinal.Text);
                cmd.Parameters.AddWithValue("@p9", lblMobilProgOrt.Text);
                cmd.Parameters.AddWithValue("@p10", txtYazilimMimarileriVize.Text);
                cmd.Parameters.AddWithValue("@p11", txtYazılımMimarileriFinal.Text);
                cmd.Parameters.AddWithValue("@p12", lblYazılımMimarileriOrt.Text);
                cmd.Parameters.AddWithValue("@p13", txtSemantikWebVize.Text);
                cmd.Parameters.AddWithValue("@p14", txtSemantikWebFinal.Text);
                cmd.Parameters.AddWithValue("@p15", lblSemantikWebOrt.Text);
                cmd.Parameters.AddWithValue("@p16", ogrNo[0]);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Öğrenci'ye Not Ataması Başarılı!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
            }
            else
            {
                MessageBox.Show("Öncelikle öğrenci seçin!", "Uyerı", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void cmbOgrenciSec_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.Open();
            string[] ogrNo = cmbOgrenciSec.Text.Split('-');
            cmd = new OleDbCommand("select * from notlar where ogrenci_numara=@numara", conn);
            cmd.Parameters.Add("@numara", ogrNo[0]);
 

            cmd.ExecuteNonQuery();
            OleDbDataReader deger = cmd.ExecuteReader();

            while (deger.Read())
            {
                txtMatematikVize.Text = deger["MatVize"].ToString();
                txtMatematikFinal.Text = deger["MatFinal"].ToString();
                lblMatematikOrt.Text = deger["MatOrt"].ToString();

                txtFizikFinal.Text = deger["FizikFinal"].ToString();
                txtFizikVize.Text = deger["FizikVize"].ToString();
                lblFizikOrt.Text = deger["FizikOrt"].ToString();


                lblMobilProgOrt.Text = deger["MobilProgOrt"].ToString();
                txtMobilProgVize.Text = deger["MobilProgVize"].ToString();
                txtMobilProgFinal.Text = deger["MobilProgFinal"].ToString();



                lblSemantikWebOrt.Text = deger["SemantikWebOrt"].ToString();
                txtSemantikWebFinal.Text = deger["SemantikWebFinal"].ToString();
                txtSemantikWebVize.Text = deger["SemantikWebVize"].ToString();


                lblYazılımMimarileriOrt.Text = deger["YazılımMimariOrt"].ToString();
                txtYazilimMimarileriVize.Text = deger["YazılımMimariVize"].ToString();
                txtYazılımMimarileriFinal.Text = deger["YazılımMimariFinal"].ToString();
            }

            conn.Close();
        }

        private void btnOgrencidenGelenMesaj_Click(object sender, EventArgs e)
        {
            MesajlarForm msj = new MesajlarForm();
            this.Hide();
            msj.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }
    }
}
