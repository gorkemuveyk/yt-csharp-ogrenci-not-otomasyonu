﻿namespace Öğrenci_Not_Otomasyonu
{
    partial class OgrenciBilgileriFormu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OgrenciBilgileriFormu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblOgrenciAdi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dersBirNot = new System.Windows.Forms.Label();
            this.dersIkiNot = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dersUcNot = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dersDortNot = new System.Windows.Forms.Label();
            this.dersBesNot = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnOgretmeneMesajGonder = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(309, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(121, 43);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // lblOgrenciAdi
            // 
            this.lblOgrenciAdi.Font = new System.Drawing.Font("Palatino Linotype", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOgrenciAdi.ForeColor = System.Drawing.Color.White;
            this.lblOgrenciAdi.Location = new System.Drawing.Point(1, 146);
            this.lblOgrenciAdi.Name = "lblOgrenciAdi";
            this.lblOgrenciAdi.Size = new System.Drawing.Size(342, 37);
            this.lblOgrenciAdi.TabIndex = 3;
            this.lblOgrenciAdi.Text = "ali";
            this.lblOgrenciAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblOgrenciAdi.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(125, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 22);
            this.label2.TabIndex = 4;
            this.label2.Text = "Fizik:";
            // 
            // dersBirNot
            // 
            this.dersBirNot.AutoSize = true;
            this.dersBirNot.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dersBirNot.ForeColor = System.Drawing.Color.White;
            this.dersBirNot.Location = new System.Drawing.Point(172, 214);
            this.dersBirNot.Name = "dersBirNot";
            this.dersBirNot.Size = new System.Drawing.Size(18, 22);
            this.dersBirNot.TabIndex = 5;
            this.dersBirNot.Text = "0";
            // 
            // dersIkiNot
            // 
            this.dersIkiNot.AutoSize = true;
            this.dersIkiNot.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dersIkiNot.ForeColor = System.Drawing.Color.White;
            this.dersIkiNot.Location = new System.Drawing.Point(172, 247);
            this.dersIkiNot.Name = "dersIkiNot";
            this.dersIkiNot.Size = new System.Drawing.Size(18, 22);
            this.dersIkiNot.TabIndex = 7;
            this.dersIkiNot.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(80, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 22);
            this.label5.TabIndex = 6;
            this.label5.Text = "Matematik:";
            // 
            // dersUcNot
            // 
            this.dersUcNot.AutoSize = true;
            this.dersUcNot.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dersUcNot.ForeColor = System.Drawing.Color.White;
            this.dersUcNot.Location = new System.Drawing.Point(172, 280);
            this.dersUcNot.Name = "dersUcNot";
            this.dersUcNot.Size = new System.Drawing.Size(18, 22);
            this.dersUcNot.TabIndex = 9;
            this.dersUcNot.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(53, 279);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 22);
            this.label7.TabIndex = 8;
            this.label7.Text = "Semantik Web:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 312);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 22);
            this.label10.TabIndex = 10;
            this.label10.Text = "Mobil Programlama:";
            // 
            // dersDortNot
            // 
            this.dersDortNot.AutoSize = true;
            this.dersDortNot.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dersDortNot.ForeColor = System.Drawing.Color.White;
            this.dersDortNot.Location = new System.Drawing.Point(172, 313);
            this.dersDortNot.Name = "dersDortNot";
            this.dersDortNot.Size = new System.Drawing.Size(18, 22);
            this.dersDortNot.TabIndex = 11;
            this.dersDortNot.Text = "0";
            // 
            // dersBesNot
            // 
            this.dersBesNot.AutoSize = true;
            this.dersBesNot.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dersBesNot.ForeColor = System.Drawing.Color.White;
            this.dersBesNot.Location = new System.Drawing.Point(172, 346);
            this.dersBesNot.Name = "dersBesNot";
            this.dersBesNot.Size = new System.Drawing.Size(18, 22);
            this.dersBesNot.TabIndex = 13;
            this.dersBesNot.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(21, 345);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(155, 22);
            this.label13.TabIndex = 12;
            this.label13.Text = "Yazılım Mimarileri:";
            // 
            // btnOgretmeneMesajGonder
            // 
            this.btnOgretmeneMesajGonder.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnOgretmeneMesajGonder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnOgretmeneMesajGonder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOgretmeneMesajGonder.ForeColor = System.Drawing.Color.White;
            this.btnOgretmeneMesajGonder.Location = new System.Drawing.Point(66, 416);
            this.btnOgretmeneMesajGonder.Name = "btnOgretmeneMesajGonder";
            this.btnOgretmeneMesajGonder.Size = new System.Drawing.Size(215, 46);
            this.btnOgretmeneMesajGonder.TabIndex = 18;
            this.btnOgretmeneMesajGonder.Text = "ÖĞRETMENE MESAJ GÖNDER";
            this.btnOgretmeneMesajGonder.UseVisualStyleBackColor = true;
            this.btnOgretmeneMesajGonder.Click += new System.EventHandler(this.btnOgretmeneMesajGonder_Click);
            // 
            // OgrenciBilgileriFormu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(348, 474);
            this.Controls.Add(this.btnOgretmeneMesajGonder);
            this.Controls.Add(this.dersBesNot);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dersDortNot);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dersUcNot);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dersIkiNot);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dersBirNot);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblOgrenciAdi);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "OgrenciBilgileriFormu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OgrenciBilgileriFormu";
            this.Load += new System.EventHandler(this.OgrenciBilgileriFormu_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OgrenciBilgileriFormu_MouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblOgrenciAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label dersBirNot;
        private System.Windows.Forms.Label dersIkiNot;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label dersUcNot;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label dersDortNot;
        private System.Windows.Forms.Label dersBesNot;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnOgretmeneMesajGonder;
    }
}