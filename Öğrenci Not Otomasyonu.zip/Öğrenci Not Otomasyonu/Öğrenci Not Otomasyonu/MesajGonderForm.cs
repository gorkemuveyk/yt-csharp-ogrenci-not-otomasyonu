﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Öğrenci_Not_Otomasyonu
{
    public partial class MesajGonderForm : Form
    {
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\veritabani.accdb");
        public MesajGonderForm()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OgrenciBilgileriFormu pgr = new OgrenciBilgileriFormu();
            this.Hide();
            pgr.Show();

        }

        private void btnMesajGonder_Click(object sender, EventArgs e)
        {
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("insert into mesajlar (mesaj_konu, mesaj_icerik, mesaj_kimden) values (@p1, @p2, @p3)", conn);
            cmd.Parameters.AddWithValue("@p1", txtKonu.Text);
            cmd.Parameters.AddWithValue("@p2", txtMesaj.Text);
            cmd.Parameters.AddWithValue("@p3", Form1.ogrNo);


            cmd.ExecuteNonQuery();   
            MessageBox.Show("Mesaj başarıyla gönderildi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            conn.Close();
        }

        private void MesajGonderForm_Load(object sender, EventArgs e)
        {

        }
    }
}
