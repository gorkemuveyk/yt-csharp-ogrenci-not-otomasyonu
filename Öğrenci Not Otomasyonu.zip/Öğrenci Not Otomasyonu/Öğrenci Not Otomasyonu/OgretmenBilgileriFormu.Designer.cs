﻿namespace Öğrenci_Not_Otomasyonu
{
    partial class OgretmenBilgileriFormu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OgretmenBilgileriFormu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnNotVer = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblSemantikWebOrt = new System.Windows.Forms.Label();
            this.txtSemantikWebFinal = new System.Windows.Forms.TextBox();
            this.txtSemantikWebVize = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblYazılımMimarileriOrt = new System.Windows.Forms.Label();
            this.txtYazılımMimarileriFinal = new System.Windows.Forms.TextBox();
            this.txtYazilimMimarileriVize = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblMobilProgOrt = new System.Windows.Forms.Label();
            this.txtMobilProgFinal = new System.Windows.Forms.TextBox();
            this.txtMobilProgVize = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblFizikOrt = new System.Windows.Forms.Label();
            this.txtFizikFinal = new System.Windows.Forms.TextBox();
            this.txtFizikVize = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblMatematikOrt = new System.Windows.Forms.Label();
            this.txtMatematikFinal = new System.Windows.Forms.TextBox();
            this.txtMatematikVize = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbOgrenciSec = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.txtTelefon = new System.Windows.Forms.MaskedTextBox();
            this.txtErkek = new System.Windows.Forms.RadioButton();
            this.txtKadin = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.txtOgrNumara = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtOgrSoyad = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtOgrAd = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.btnKamera = new System.Windows.Forms.Button();
            this.btnGozat = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnOgrencidenGelenMesaj = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(793, 3);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(18, 18);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(101, 43);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 28);
            this.label1.TabIndex = 4;
            this.label1.Text = "Hasan Ali Ötüken";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnNotVer);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.lblSemantikWebOrt);
            this.groupBox1.Controls.Add(this.txtSemantikWebFinal);
            this.groupBox1.Controls.Add(this.txtSemantikWebVize);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.lblYazılımMimarileriOrt);
            this.groupBox1.Controls.Add(this.txtYazılımMimarileriFinal);
            this.groupBox1.Controls.Add(this.txtYazilimMimarileriVize);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.lblMobilProgOrt);
            this.groupBox1.Controls.Add(this.txtMobilProgFinal);
            this.groupBox1.Controls.Add(this.txtMobilProgVize);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblFizikOrt);
            this.groupBox1.Controls.Add(this.txtFizikFinal);
            this.groupBox1.Controls.Add(this.txtFizikVize);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lblMatematikOrt);
            this.groupBox1.Controls.Add(this.txtMatematikFinal);
            this.groupBox1.Controls.Add(this.txtMatematikVize);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmbOgrenciSec);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(18, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(313, 411);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Öğrenci Not Giriş Alanı";
            // 
            // btnNotVer
            // 
            this.btnNotVer.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnNotVer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnNotVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotVer.Location = new System.Drawing.Point(143, 363);
            this.btnNotVer.Name = "btnNotVer";
            this.btnNotVer.Size = new System.Drawing.Size(106, 32);
            this.btnNotVer.TabIndex = 11;
            this.btnNotVer.Text = "Not Ver";
            this.btnNotVer.UseVisualStyleBackColor = true;
            this.btnNotVer.Click += new System.EventHandler(this.btnNotVer_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(208, 302);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 17);
            this.label19.TabIndex = 31;
            this.label19.Text = "Final";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(153, 302);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 17);
            this.label20.TabIndex = 30;
            this.label20.Text = "Vize";
            // 
            // lblSemantikWebOrt
            // 
            this.lblSemantikWebOrt.AutoSize = true;
            this.lblSemantikWebOrt.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSemantikWebOrt.Location = new System.Drawing.Point(255, 326);
            this.lblSemantikWebOrt.Name = "lblSemantikWebOrt";
            this.lblSemantikWebOrt.Size = new System.Drawing.Size(0, 17);
            this.lblSemantikWebOrt.TabIndex = 29;
            // 
            // txtSemantikWebFinal
            // 
            this.txtSemantikWebFinal.Location = new System.Drawing.Point(200, 320);
            this.txtSemantikWebFinal.MaxLength = 3;
            this.txtSemantikWebFinal.Name = "txtSemantikWebFinal";
            this.txtSemantikWebFinal.Size = new System.Drawing.Size(49, 28);
            this.txtSemantikWebFinal.TabIndex = 10;
            this.txtSemantikWebFinal.TextChanged += new System.EventHandler(this.txtSemantikWebFinal_TextChanged);
            this.txtSemantikWebFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // txtSemantikWebVize
            // 
            this.txtSemantikWebVize.Location = new System.Drawing.Point(145, 320);
            this.txtSemantikWebVize.MaxLength = 3;
            this.txtSemantikWebVize.Name = "txtSemantikWebVize";
            this.txtSemantikWebVize.Size = new System.Drawing.Size(49, 28);
            this.txtSemantikWebVize.TabIndex = 9;
            this.txtSemantikWebVize.TextChanged += new System.EventHandler(this.txtSemantikWebVize_TextChanged);
            this.txtSemantikWebVize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(37, 321);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 20);
            this.label22.TabIndex = 26;
            this.label22.Text = "Semantik Web:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(208, 246);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 17);
            this.label15.TabIndex = 25;
            this.label15.Text = "Final";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(153, 246);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 17);
            this.label16.TabIndex = 24;
            this.label16.Text = "Vize";
            // 
            // lblYazılımMimarileriOrt
            // 
            this.lblYazılımMimarileriOrt.AutoSize = true;
            this.lblYazılımMimarileriOrt.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYazılımMimarileriOrt.Location = new System.Drawing.Point(255, 270);
            this.lblYazılımMimarileriOrt.Name = "lblYazılımMimarileriOrt";
            this.lblYazılımMimarileriOrt.Size = new System.Drawing.Size(0, 17);
            this.lblYazılımMimarileriOrt.TabIndex = 23;
            // 
            // txtYazılımMimarileriFinal
            // 
            this.txtYazılımMimarileriFinal.Location = new System.Drawing.Point(200, 264);
            this.txtYazılımMimarileriFinal.MaxLength = 3;
            this.txtYazılımMimarileriFinal.Name = "txtYazılımMimarileriFinal";
            this.txtYazılımMimarileriFinal.Size = new System.Drawing.Size(49, 28);
            this.txtYazılımMimarileriFinal.TabIndex = 8;
            this.txtYazılımMimarileriFinal.TextChanged += new System.EventHandler(this.txtYazılımMimarileriFinal_TextChanged);
            this.txtYazılımMimarileriFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // txtYazilimMimarileriVize
            // 
            this.txtYazilimMimarileriVize.Location = new System.Drawing.Point(145, 264);
            this.txtYazilimMimarileriVize.MaxLength = 3;
            this.txtYazilimMimarileriVize.Name = "txtYazilimMimarileriVize";
            this.txtYazilimMimarileriVize.Size = new System.Drawing.Size(49, 28);
            this.txtYazilimMimarileriVize.TabIndex = 7;
            this.txtYazilimMimarileriVize.TextChanged += new System.EventHandler(this.txtYazilimMimarileriVize_TextChanged);
            this.txtYazilimMimarileriVize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 266);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(136, 20);
            this.label18.TabIndex = 20;
            this.label18.Text = "Yazılım Mimarileri:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(208, 189);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 17);
            this.label11.TabIndex = 19;
            this.label11.Text = "Final";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(153, 189);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 17);
            this.label12.TabIndex = 18;
            this.label12.Text = "Vize";
            // 
            // lblMobilProgOrt
            // 
            this.lblMobilProgOrt.AutoSize = true;
            this.lblMobilProgOrt.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobilProgOrt.Location = new System.Drawing.Point(255, 213);
            this.lblMobilProgOrt.Name = "lblMobilProgOrt";
            this.lblMobilProgOrt.Size = new System.Drawing.Size(0, 17);
            this.lblMobilProgOrt.TabIndex = 17;
            // 
            // txtMobilProgFinal
            // 
            this.txtMobilProgFinal.Location = new System.Drawing.Point(200, 207);
            this.txtMobilProgFinal.MaxLength = 3;
            this.txtMobilProgFinal.Name = "txtMobilProgFinal";
            this.txtMobilProgFinal.Size = new System.Drawing.Size(49, 28);
            this.txtMobilProgFinal.TabIndex = 6;
            this.txtMobilProgFinal.TextChanged += new System.EventHandler(this.txtMobilProgFinal_TextChanged);
            this.txtMobilProgFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // txtMobilProgVize
            // 
            this.txtMobilProgVize.Location = new System.Drawing.Point(145, 207);
            this.txtMobilProgVize.MaxLength = 3;
            this.txtMobilProgVize.Name = "txtMobilProgVize";
            this.txtMobilProgVize.Size = new System.Drawing.Size(49, 28);
            this.txtMobilProgVize.TabIndex = 5;
            this.txtMobilProgVize.TextChanged += new System.EventHandler(this.txtMobilProgVize_TextChanged);
            this.txtMobilProgVize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1, 209);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(147, 20);
            this.label14.TabIndex = 14;
            this.label14.Text = "Mobil Programlama:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(208, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Final";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(153, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "Vize";
            // 
            // lblFizikOrt
            // 
            this.lblFizikOrt.AutoSize = true;
            this.lblFizikOrt.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFizikOrt.Location = new System.Drawing.Point(255, 160);
            this.lblFizikOrt.Name = "lblFizikOrt";
            this.lblFizikOrt.Size = new System.Drawing.Size(0, 17);
            this.lblFizikOrt.TabIndex = 11;
            // 
            // txtFizikFinal
            // 
            this.txtFizikFinal.Location = new System.Drawing.Point(200, 154);
            this.txtFizikFinal.MaxLength = 3;
            this.txtFizikFinal.Name = "txtFizikFinal";
            this.txtFizikFinal.Size = new System.Drawing.Size(49, 28);
            this.txtFizikFinal.TabIndex = 4;
            this.txtFizikFinal.TextChanged += new System.EventHandler(this.txtFizikFinal_TextChanged);
            this.txtFizikFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // txtFizikVize
            // 
            this.txtFizikVize.Location = new System.Drawing.Point(145, 154);
            this.txtFizikVize.MaxLength = 3;
            this.txtFizikVize.Name = "txtFizikVize";
            this.txtFizikVize.Size = new System.Drawing.Size(49, 28);
            this.txtFizikVize.TabIndex = 3;
            this.txtFizikVize.TextChanged += new System.EventHandler(this.txtFizikVize_TextChanged);
            this.txtFizikVize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFizikVize_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(103, 157);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "Fizik:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(208, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "Final";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(153, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Vize";
            // 
            // lblMatematikOrt
            // 
            this.lblMatematikOrt.AutoSize = true;
            this.lblMatematikOrt.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatematikOrt.Location = new System.Drawing.Point(255, 108);
            this.lblMatematikOrt.Name = "lblMatematikOrt";
            this.lblMatematikOrt.Size = new System.Drawing.Size(0, 17);
            this.lblMatematikOrt.TabIndex = 5;
            // 
            // txtMatematikFinal
            // 
            this.txtMatematikFinal.Location = new System.Drawing.Point(200, 102);
            this.txtMatematikFinal.MaxLength = 3;
            this.txtMatematikFinal.Name = "txtMatematikFinal";
            this.txtMatematikFinal.Size = new System.Drawing.Size(49, 28);
            this.txtMatematikFinal.TabIndex = 2;
            this.txtMatematikFinal.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.txtMatematikFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // txtMatematikVize
            // 
            this.txtMatematikVize.Location = new System.Drawing.Point(145, 102);
            this.txtMatematikVize.MaxLength = 3;
            this.txtMatematikVize.Name = "txtMatematikVize";
            this.txtMatematikVize.Size = new System.Drawing.Size(49, 28);
            this.txtMatematikVize.TabIndex = 1;
            this.txtMatematikVize.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtMatematikVize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Matematik:";
            // 
            // cmbOgrenciSec
            // 
            this.cmbOgrenciSec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOgrenciSec.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOgrenciSec.FormattingEnabled = true;
            this.cmbOgrenciSec.Location = new System.Drawing.Point(98, 43);
            this.cmbOgrenciSec.Name = "cmbOgrenciSec";
            this.cmbOgrenciSec.Size = new System.Drawing.Size(192, 26);
            this.cmbOgrenciSec.TabIndex = 0;
            this.cmbOgrenciSec.SelectedIndexChanged += new System.EventHandler(this.cmbOgrenciSec_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Öğrenci Seç:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.btnKaydet);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.txtTelefon);
            this.groupBox2.Controls.Add(this.txtErkek);
            this.groupBox2.Controls.Add(this.txtKadin);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtOgrNumara);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtOgrSoyad);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtOgrAd);
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btnTemizle);
            this.groupBox2.Controls.Add(this.btnKamera);
            this.groupBox2.Controls.Add(this.btnGozat);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(337, 132);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(483, 410);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Yeni Öğrenci Kaydı";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(131, 26);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(146, 25);
            this.comboBox1.TabIndex = 23;
            // 
            // btnKaydet
            // 
            this.btnKaydet.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnKaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKaydet.Location = new System.Drawing.Point(131, 354);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(179, 32);
            this.btnKaydet.TabIndex = 21;
            this.btnKaydet.Text = "Öğrenciyi Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = true;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 324);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(118, 20);
            this.label21.TabIndex = 15;
            this.label21.Text = "Öğrenci Telefon:";
            // 
            // txtTelefon
            // 
            this.txtTelefon.Location = new System.Drawing.Point(131, 320);
            this.txtTelefon.Mask = "(999) 000-0000";
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(179, 28);
            this.txtTelefon.TabIndex = 20;
            // 
            // txtErkek
            // 
            this.txtErkek.AutoSize = true;
            this.txtErkek.Location = new System.Drawing.Point(232, 292);
            this.txtErkek.Name = "txtErkek";
            this.txtErkek.Size = new System.Drawing.Size(67, 24);
            this.txtErkek.TabIndex = 19;
            this.txtErkek.TabStop = true;
            this.txtErkek.Text = "Erkek";
            this.txtErkek.UseVisualStyleBackColor = true;
            // 
            // txtKadin
            // 
            this.txtKadin.AutoSize = true;
            this.txtKadin.Location = new System.Drawing.Point(159, 290);
            this.txtKadin.Name = "txtKadin";
            this.txtKadin.Size = new System.Drawing.Size(67, 24);
            this.txtKadin.TabIndex = 18;
            this.txtKadin.TabStop = true;
            this.txtKadin.Text = "Kadın";
            this.txtKadin.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(7, 290);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(124, 20);
            this.label17.TabIndex = 11;
            this.label17.Text = "Öğrenci Cinsiyet:";
            // 
            // txtOgrNumara
            // 
            this.txtOgrNumara.Location = new System.Drawing.Point(131, 188);
            this.txtOgrNumara.Name = "txtOgrNumara";
            this.txtOgrNumara.Size = new System.Drawing.Size(179, 28);
            this.txtOgrNumara.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 188);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(125, 20);
            this.label13.TabIndex = 9;
            this.label13.Text = "Öğrenci Numara:";
            // 
            // txtOgrSoyad
            // 
            this.txtOgrSoyad.Location = new System.Drawing.Point(131, 256);
            this.txtOgrSoyad.Name = "txtOgrSoyad";
            this.txtOgrSoyad.Size = new System.Drawing.Size(179, 28);
            this.txtOgrSoyad.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 20);
            this.label9.TabIndex = 7;
            this.label9.Text = "Öğrenci Soyad:";
            // 
            // txtOgrAd
            // 
            this.txtOgrAd.Location = new System.Drawing.Point(131, 222);
            this.txtOgrAd.Name = "txtOgrAd";
            this.txtOgrAd.Size = new System.Drawing.Size(179, 28);
            this.txtOgrAd.TabIndex = 16;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(24, 61);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 100);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Öğrenci Ad:";
            // 
            // btnTemizle
            // 
            this.btnTemizle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnTemizle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTemizle.Location = new System.Drawing.Point(377, 129);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(100, 32);
            this.btnTemizle.TabIndex = 14;
            this.btnTemizle.Text = "Foto Aktar";
            this.btnTemizle.UseVisualStyleBackColor = true;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // btnKamera
            // 
            this.btnKamera.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnKamera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKamera.Location = new System.Drawing.Point(283, 61);
            this.btnKamera.Name = "btnKamera";
            this.btnKamera.Size = new System.Drawing.Size(88, 62);
            this.btnKamera.TabIndex = 13;
            this.btnKamera.Text = "Kamera Aç";
            this.btnKamera.UseVisualStyleBackColor = true;
            this.btnKamera.Click += new System.EventHandler(this.btnKamera_Click);
            // 
            // btnGozat
            // 
            this.btnGozat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnGozat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGozat.Location = new System.Drawing.Point(283, 23);
            this.btnGozat.Name = "btnGozat";
            this.btnGozat.Size = new System.Drawing.Size(88, 32);
            this.btnGozat.TabIndex = 12;
            this.btnGozat.Text = "Gözat";
            this.btnGozat.UseVisualStyleBackColor = true;
            this.btnGozat.Click += new System.EventHandler(this.btnGozat_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(377, 23);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // btnOgrencidenGelenMesaj
            // 
            this.btnOgrencidenGelenMesaj.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnOgrencidenGelenMesaj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnOgrencidenGelenMesaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOgrencidenGelenMesaj.ForeColor = System.Drawing.Color.White;
            this.btnOgrencidenGelenMesaj.Location = new System.Drawing.Point(512, 5);
            this.btnOgrencidenGelenMesaj.Name = "btnOgrencidenGelenMesaj";
            this.btnOgrencidenGelenMesaj.Size = new System.Drawing.Size(224, 32);
            this.btnOgrencidenGelenMesaj.TabIndex = 22;
            this.btnOgrencidenGelenMesaj.Text = "Öğrencilerden Gelen Mesajlar";
            this.btnOgrencidenGelenMesaj.UseVisualStyleBackColor = true;
            this.btnOgrencidenGelenMesaj.Click += new System.EventHandler(this.btnOgrencidenGelenMesaj_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // OgretmenBilgileriFormu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(832, 557);
            this.Controls.Add(this.btnOgrencidenGelenMesaj);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "OgretmenBilgileriFormu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OgretmenBilgileriFormu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OgretmenBilgileriFormu_FormClosing);
            this.Load += new System.EventHandler(this.OgretmenBilgileriFormu_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OgretmenBilgileriFormu_MouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbOgrenciSec;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMatematikVize;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMatematikOrt;
        private System.Windows.Forms.TextBox txtMatematikFinal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblSemantikWebOrt;
        private System.Windows.Forms.TextBox txtSemantikWebFinal;
        private System.Windows.Forms.TextBox txtSemantikWebVize;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblYazılımMimarileriOrt;
        private System.Windows.Forms.TextBox txtYazılımMimarileriFinal;
        private System.Windows.Forms.TextBox txtYazilimMimarileriVize;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblMobilProgOrt;
        private System.Windows.Forms.TextBox txtMobilProgFinal;
        private System.Windows.Forms.TextBox txtMobilProgVize;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblFizikOrt;
        private System.Windows.Forms.TextBox txtFizikFinal;
        private System.Windows.Forms.TextBox txtFizikVize;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnNotVer;
        private System.Windows.Forms.Button btnGozat;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.Button btnKamera;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOgrAd;
        private System.Windows.Forms.TextBox txtOgrNumara;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtOgrSoyad;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton txtErkek;
        private System.Windows.Forms.RadioButton txtKadin;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MaskedTextBox txtTelefon;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Button btnOgrencidenGelenMesaj;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}